package com.example.demo.service;

import java.util.List;

import com.example.demo.model.HomeProperty;
import com.example.demo.model.Registration;
public interface IHomePropertyService {
public abstract HomeProperty saveHomeProperty(HomeProperty homeProperty);
public abstract List<HomeProperty> fetchHomeProperty(HomeProperty homeProperty);
public abstract HomeProperty updateHomeProperty(HomeProperty homeProperty,int homeId);
public abstract void deleteHomeProperty(int homeId,HomeProperty homeProperty);
public abstract List<HomeProperty> findByAreaAndStreet(String area,String street);
public abstract List<HomeProperty> findByState(String state);
public abstract List<HomeProperty> findByCity(String city);
public abstract List<HomeProperty> findByCityAndAreaAndLandmark(String city,String area,String landmark);
public abstract List<HomeProperty> findByStateAndCity(String city,String State);
public abstract List<HomeProperty> findByPriceRange(double startPrice,double EndPrice);
public abstract boolean login(String userName,String password);
public abstract boolean Register(Registration register);

}
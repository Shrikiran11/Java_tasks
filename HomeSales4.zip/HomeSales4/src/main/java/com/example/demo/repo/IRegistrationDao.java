package com.example.demo.repo;

import java.util.List;


import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.example.demo.model.HomeProperty;
import com.example.demo.model.Registration;
@Repository
public interface IRegistrationDao extends JpaRepository<Registration,Integer>{
	public abstract List<HomeProperty> findByUserNameAndPassword(String userName,String password);
	
}


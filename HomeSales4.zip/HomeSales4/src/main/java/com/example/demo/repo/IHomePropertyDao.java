package com.example.demo.repo;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;

import com.example.demo.model.HomeProperty;

public interface IHomePropertyDao extends JpaRepository<HomeProperty,Integer> {
	
	public abstract List<HomeProperty> findByAreaAndStreet(String area,String street);
	public abstract List<HomeProperty> findByState(String state);
	public abstract List<HomeProperty> findByCity(String city);
	public abstract List<HomeProperty> findByCityAndAreaAndLandmark(String city,String area,String landmark);
	public abstract List<HomeProperty> findByStateAndCity(String city,String State);
	
}
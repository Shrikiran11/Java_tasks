package com.example.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.HomeProperty;
import com.example.demo.repo.ILocationDao;

public class LocationServiceImpl implements ILocationService {
	@Autowired
	private ILocationDao iLocationDao;

	@Override
	public List<HomeProperty> findByAreaAndStreet(String area, String street) {
		
		return null;
	}

	@Override
	public List<HomeProperty> findByState(String state) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HomeProperty> findByCity(String city) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HomeProperty> findByCityAndAreaAndLandmark(String city, String area, String landmark) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public List<HomeProperty> findByStateAndCity(String city, String State) {
		// TODO Auto-generated method stub
		return null;
	}

}

package com.example.demo.model;

import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

public class Location {
@Id
@GeneratedValue(strategy=GenerationType.AUTO)
int locId;
String st;
int pincode;
String landmark;
String Area;
String city;
String state;
//@OneToMany(mappedBy="Location")
//private HomeProperty homeProperty;
}

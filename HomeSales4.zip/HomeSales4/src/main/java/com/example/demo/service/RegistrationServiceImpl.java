package com.example.demo.service;

import org.springframework.beans.factory.annotation.Autowired;

import com.example.demo.model.Registration;
import com.example.demo.repo.IRegistrationDao;

public class RegistrationServiceImpl implements IRegistrationService{
@Autowired
private IRegistrationDao iRegistrationRepo;
	@Override
	public void Register(Registration registeration) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void login(String userName, String password) {
		// TODO Auto-generated method stub
		
	}

}

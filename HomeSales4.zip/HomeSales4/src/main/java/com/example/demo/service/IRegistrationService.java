package com.example.demo.service;

import com.example.demo.model.Registration;

public interface IRegistrationService {
public abstract void Register(Registration registeration);
public abstract void login(String userName,String password);
}

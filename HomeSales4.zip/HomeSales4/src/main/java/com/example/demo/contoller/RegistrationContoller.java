package com.example.demo.contoller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.Registration;
import com.example.demo.service.RegistrationServiceImpl;

@RestController
public class RegistrationContoller {
@Autowired
private RegistrationServiceImpl registrationServiceImpl;
@GetMapping("/Register")
public boolean Register(@RequestParam(defaultValue="Guest") String userName,@RequestParam(required=true)String phoneNo,@RequestParam(required=true)String emailId,@RequestParam(required=true)String password,@RequestParam(required=true)String role) {
	Registration register=new Registration();
	register.setUsername(userName);
	register.setPassword(password);
	register.setEmailId(emailId);
	register.setRole(role);
		return true;
}
	@GetMapping("/login")
	public boolean login(@RequestParam(required=true)String userName,@RequestParam(required=true)String password,@RequestParam(required=true)String role) {
		return true;
	}

}

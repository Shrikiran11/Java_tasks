package com.example.demo.contoller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.example.demo.model.HomeProperty;
import com.example.demo.service.HomePropertyServiceImpl;

@RestController
public class HomePropertyContoller {
@Autowired
private HomePropertyServiceImpl homePropertyServiceImpl;

@RequestMapping("/filterState")
public List<HomeProperty> findByState(@RequestParam(required=true) String state){
	List list=homePropertyServiceImpl.findByState(state);
	return list;
}
@RequestMapping("/filterCity")
public List<HomeProperty> findByCity(@RequestParam(required=true) String city){
	List list=homePropertyServiceImpl.findByCity(city);
	return list;
}
@RequestMapping("/filterStateAndCity")
public List<HomeProperty> findByStateAndCity(@RequestParam(required=true) String state,@RequestParam(required=true) String city){
	List list=homePropertyServiceImpl.findByStateAndCity(city, state);
	return list;
}
@RequestMapping("/filterCityAndAreaAndLandmark")
public List<HomeProperty> filterCityAndAreaAndLandmark(@RequestParam(required=true) String city,@RequestParam(required=true) String area,@RequestParam(required=true) String landmark){
	List list=homePropertyServiceImpl.findByCityAndAreaAndLandmark(city, area, landmark);
	return list;
}

}

package com.example.demo;

public class FloorType {
private String material;
private String color;
private String size;
}

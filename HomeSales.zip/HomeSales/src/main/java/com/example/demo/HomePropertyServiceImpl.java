package com.example.demo;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class HomePropertyServiceImpl implements IHomePropertyService {
	@Autowired
 private IHomePropertyDao homePropertyDao;

	@Override
	public HomeProperty saveHomeProperty(HomeProperty homeProperty) {
		// TODO Auto-generated method stub
		homePropertyDao.save(homeProperty);
		return null;
	}

	@Override
	public List<HomeProperty> fetchHomeProperty(HomeProperty homeProperty) {
		// TODO Auto-generated method stub
		homePropertyDao.findAll();
		return null;
	}

	@Override
	public HomeProperty updateHomeProperty(HomeProperty homeProperty, int homeId) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteHomeProperty(int homeId, HomeProperty homeProperty) {
		// TODO Auto-generated method stub
		homePropertyDao.deleteById(homeId);
		
	}

	@Override
	public List<HomeProperty> findByAreaAndStreet(String area, String street) {
		// TODO Auto-generated method stub
		List list=homePropertyDao.findByAreaAndStreet( area, street);
		return null;
	}

	@Override
	public List<HomeProperty> findByState(String state) {
		// TODO Auto-generated method stub
		homePropertyDao.findByState(state);
		return null;
	}

	@Override
	public List<HomeProperty> findByCity(String city) {
		// TODO Auto-generated method stub
		homePropertyDao.findByCity(city);
		return null;
	}

	@Override
	public List<HomeProperty> findByCityAndAreaAndLandmark(String city, String area, String landmark) {
		// TODO Auto-generated method stub
		homePropertyDao.findByCityAndAreaAndLandmark(city, area, landmark);
		return null;
	}

	@Override
	public List<HomeProperty> findByStateAndCity(String city, String State) {
		// TODO Auto-generated method stub
		homePropertyDao.findByStateAndCity(city, State);
		return null;
	}

	@Override
	public List<HomeProperty> findByPriceRange(double startPrice, double EndPrice) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public boolean login(String userName, String password) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean Register(String userName, String password, String confirmPassword, String email, String phoneNo) {
		// TODO Auto-generated method stub
		return false;
	}
	
}
